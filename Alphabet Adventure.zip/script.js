/*
 script.js
 The main logic for The Alphabet Game.
*/

// --- GAME STATE AND CONFIGURATION ---
const game = {
    playerName: 'Hero', currentStage: 0, currentLevel: 0, stageScore: 0, totalScore: 0,
    unlockedStages: 1, timerInterval: null, timeLeft: 0, devMode: false,
};
const stages = [
    { name: 'Letter Recognition', levels: [ { time: 60, target: 5 }, { time: 50, target: 7 }, { time: 40, target: 10 } ], hasTimer: true },
    { name: 'Letter Tracing', levels: [ { target: 3, letters: ['A', 'B', 'C', 'D'] }, { target: 4, letters: ['E', 'F', 'G', 'H'] }, { target: 5, letters: ['I', 'J', 'K', 'L', 'M'] } ], hasTimer: false },
    { name: 'Letter in Words', levels: [ { time: 60, target: 5, words: {A:'APPLE', B:'BALL', C:'CAT', D:'DOG', E:'EGG'} }, { time: 50, target: 7, words: {F:'FISH', G:'GOAT', H:'HAT', I:'IGLOO', J:'JAM', K:'KITE', L:'LION'} }, { time: 40, target: 8, words: {M:'MOON', N:'NOSE', O:'ORANGE', P:'PIG', Q:'QUEEN', R:'RAINBOW', S:'SUN', T:'TURTLE'} } ], hasTimer: true },
    { name: 'Memory Match', levels: [ { time: 90, pairs: 6 }, { time: 75, pairs: 8 }, { time: 60, pairs: 10 } ], hasTimer: true },
    { name: 'Flying Letters', levels: [ { time: 60, target: 8 }, { time: 50, target: 12 }, { time: 40, target: 15 } ], hasTimer: true }
];
const letterDetails = { 'A': { word: 'ANT', image: 'https://placehold.co/200x200/F472B6/FFFFFF?text=Ant' },'B': { word: 'BUS', image: 'https://placehold.co/200x200/FBBF24/FFFFFF?text=Bus' },'C': { word: 'CAT', image: 'https://placehold.co/200x200/A78BFA/FFFFFF?text=Cat' },'D': { word: 'DOG', image: 'https://placehold.co/200x200/60A5FA/FFFFFF?text=Dog' },'E': { word: 'EGG', image: 'https://placehold.co/200x200/34D399/FFFFFF?text=Egg' },'F': { word: 'FOX', image: 'https://placehold.co/200x200/FB923C/FFFFFF?text=Fox' },'G': { word: 'GOAT', image: 'https://placehold.co/200x200/F472B6/FFFFFF?text=Goat' },'H': { word: 'HAT', image: 'https://placehold.co/200x200/FBBF24/FFFFFF?text=Hat' },'I': { word: 'IGLOO', image: 'https://placehold.co/200x200/A78BFA/FFFFFF?text=Igloo' },'J': { word: 'JAM', image: 'https://placehold.co/200x200/60A5FA/FFFFFF?text=Jam' },'K': { word: 'KITE', image: 'https://placehold.co/200x200/34D399/FFFFFF?text=Kite' },'L': { word: 'LION', image: 'https://placehold.co/200x200/FB923C/FFFFFF?text=Lion' },'M': { word: 'MOON', image: 'https://placehold.co/200x200/F472B6/FFFFFF?text=Moon' }, };
const letterTracePaths = { 'A': [ [{x:150, y:50}, {x:90, y:250}], [{x:150, y:50}, {x:210, y:250}], [{x:120, y:150}, {x:180, y:150}] ], 'B': [ [{x:100, y:50}, {x:100, y:250}], [{x:100, y:50}, {x:180, y:70}, {x:180, y:130}, {x:100, y:150}], [{x:100, y:150}, {x:200, y:170}, {x:200, y:230}, {x:100, y:250}] ], 'C': [ [{x:220, y:100}, {x:150, y:50}, {x:80, y:100}, {x:80, y:200}, {x:150, y:250}, {x:220, y:200}] ], 'D': [ [{x:100, y:50}, {x:100, y:250}], [{x:100, y:50}, {x:180, y:70}, {x:220, y:150}, {x:180, y:230}, {x:100, y:250}] ], 'E': [ [{x:100, y:50}, {x:100, y:250}], [{x:100, y:50}, {x:200, y:50}], [{x:100, y:150}, {x:180, y:150}], [{x:100, y:250}, {x:200, y:250}] ], 'F': [ [{x:100, y:50}, {x:100, y:250}], [{x:100, y:50}, {x:200, y:50}], [{x:100, y:150}, {x:180, y:150}] ], 'G': [ [{x:220, y:100}, {x:150, y:50}, {x:80, y:100}, {x:80, y:200}, {x:150, y:250}, {x:220, y:200}, {x:220, y:150}, {x:170, y:150}] ], 'H': [ [{x:80, y:50}, {x:80, y:250}], [{x:200, y:50}, {x:200, y:250}], [{x:80, y:150}, {x:200, y:150}] ], 'I': [ [{x:150, y:50}, {x:150, y:250}], [{x:100, y:50}, {x:200, y:50}], [{x:100, y:250}, {x:200, y:250}] ], 'J': [ [{x:200, y:50}, {x:200, y:220}, {x:150, y:250}, {x:100, y:220}] ], 'K': [ [{x:100, y:50}, {x:100, y:250}], [{x:200, y:50}, {x:100, y:150}], [{x:100, y:150}, {x:200, y:250}] ], 'L': [ [{x:100, y:50}, {x:100, y:250}], [{x:100, y:250}, {x:200, y:250}] ], 'M': [ [{x:80, y:250}, {x:80, y:50}], [{x:80, y:50}, {x:150, y:150}], [{x:150, y:150}, {x:220, y:50}], [{x:220, y:50}, {x:220, y:250}] ] };
const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

// --- UTILITY AND HELPER FUNCTIONS ---
const getEl = (id) => document.getElementById(id);
const screens = { name: () => getEl('name-screen'), map: () => getEl('map-screen'), game: () => getEl('game-screen'), win: () => getEl('win-screen') };
const synth = new Tone.PolySynth(Tone.Synth).toDestination();
const winMusic = new Tone.Synth({ oscillator: { type: "pulse", width: 0.6 }, envelope: { attack: 0.01, decay: 0.1, sustain: 0.2, release: 0.4 } }).toDestination();
function playSound(note, duration) { if (Tone.context.state !== 'running') { Tone.context.resume(); } synth.triggerAttackRelease(note, duration); }
function playWinMusic() {
    if (Tone.context.state !== 'running') { Tone.context.resume(); }
    const now = Tone.now();
    winMusic.triggerAttackRelease("C4", "8n", now); winMusic.triggerAttackRelease("E4", "8n", now + 0.2);
    winMusic.triggerAttackRelease("G4", "8n", now + 0.4); winMusic.triggerAttackRelease("C5", "4n", now + 0.6);
}
function speak(text) { if ('speechSynthesis' in window) { speechSynthesis.cancel(); const u = new SpeechSynthesisUtterance(text); u.lang = 'en-US'; speechSynthesis.speak(u); } }
function showScreen(name) { Object.values(screens).forEach(s => s().classList.add('hidden')); screens[name]().classList.remove('hidden'); screens[name]().classList.add('flex'); }
function showModal(title, text, btn, cb) { getEl('modal-title').textContent = title; getEl('modal-text').innerHTML = text; const oldBtn = getEl('modal-btn'); const newBtn = oldBtn.cloneNode(true); newBtn.textContent = btn; oldBtn.parentNode.replaceChild(newBtn, oldBtn); newBtn.addEventListener('click', () => { getEl('modal').classList.add('hidden'); cb(); }, { once: true }); getEl('modal').classList.remove('hidden'); }

function updateMap(isInitialLoad = false, justUnlockedIndex = -1) { 
    document.querySelectorAll('.stage-node').forEach((node, i) => {
        const isNowUnlocked = i < game.unlockedStages;
        const wasUnlockedBefore = node.classList.contains('unlocked');
        node.classList.remove('unlocked', 'completed', 'just-unlocked');
        setTimeout(() => { node.classList.add('visible'); }, isInitialLoad ? 150 * i : 0);
        if(isNowUnlocked) {
            node.classList.add('unlocked');
             node.onclick = () => { game.currentStage = i; game.currentLevel = 0; loadLevel(); };
             if(i < game.currentStage) {
                 node.classList.add('completed');
             }
             if(i === justUnlockedIndex) {
                 node.classList.add('just-unlocked');
             }
        } else {
            node.onclick = null;
        }
    });
}
function updateScore(points) {
    game.stageScore += points;
    game.totalScore += points;
    getEl('stage-score').textContent = game.stageScore;
    getEl('total-score').textContent = game.totalScore;
}


// --- CORE GAME LOGIC & NAVIGATION ---
function loadLevel() {
    const stageData = stages[game.currentStage];
    const levelData = stageData.levels[game.currentLevel];
    if (!stageData || !levelData) { return; }
    game.stageScore = 0;
    updateScore(0);
    getEl('level-title').textContent = `${stageData.name} - Level ${game.currentLevel + 1}`;
    getEl('timer-container').style.display = stageData.hasTimer ? 'flex' : 'none';
    if (stageData.hasTimer) { startTimer(levelData.time); } else { clearInterval(game.timerInterval); }
    showScreen('game');
    const stageFunctions = [loadStage1, loadStage2, loadStage3, loadStage4, loadStage5];
    stageFunctions[game.currentStage](levelData);
}

function levelWon() {
    clearInterval(game.timerInterval); playSound('C5', '0.2'); game.currentLevel++;
    const stageData = stages[game.currentStage];
    if (game.currentLevel >= stageData.levels.length) {
        const wasUnlocked = game.unlockedStages;
        game.unlockedStages = Math.max(game.unlockedStages, game.currentStage + 1);
        const justUnlockedNewStage = game.unlockedStages > wasUnlocked;
        game.currentStage++; game.currentLevel = 0;
        if (game.currentStage >= stages.length) { showWinScreen(); } 
        else { showModal('Stage Complete!', `Great job! You unlocked Stage ${game.currentStage + 1}.`, 'Start Next Stage', () => {
            updateMap(false, justUnlockedNewStage ? game.currentStage : -1);
            loadLevel();
        }); }
    } else { showModal('Level Passed!', `Awesome work, ${game.playerName}!`, 'Next Level', loadLevel); }
}

function levelLost() { clearInterval(game.timerInterval); playSound('C3', '0.5'); showModal('Time\'s Up!', 'Don\'t worry, try again!', 'Retry', loadLevel); }
function startTimer(duration) { game.timeLeft = duration; getEl('timer').textContent = game.timeLeft; clearInterval(game.timerInterval); game.timerInterval = setInterval(() => { game.timeLeft--; getEl('timer').textContent = game.timeLeft; if (game.timeLeft <= 0) { levelLost(); } }, 1000); }

// --- STAGE 1: Letter Recognition ---
function loadStage1(levelData) {
    let correctAnswers = 0;
    const nextQuestion = () => {
        if (correctAnswers >= levelData.target) { levelWon(); return; }
        const correctAnswer = alphabet[Math.floor(Math.random() * alphabet.length)];
        const options = new Set([correctAnswer]);
        while (options.size < 3) { options.add(alphabet[Math.floor(Math.random() * alphabet.length)]); }
        const shuffledOptions = Array.from(options).sort(() => Math.random() - 0.5);
        getEl('game-area').innerHTML = `<div class="text-center"><p class="text-xl sm:text-3xl text-slate-700">Find the letter:</p><div class="flex items-center justify-center gap-4 my-2 sm:my-4"><h2 class="font-header text-8xl sm:text-9xl text-sky-500">${correctAnswer}</h2><button id="speaker-btn" class="btn-icon text-5xl">🔊</button></div></div><div class="flex gap-2 sm:gap-4 mt-4 flex-wrap justify-center">${shuffledOptions.map(opt => `<button class="option-btn btn-game btn-secondary text-3xl sm:text-5xl p-4 w-20 h-20 sm:w-32 sm:h-32 flex items-center justify-center rounded-3xl" data-letter="${opt}">${opt}</button>`).join('')}</div><div class="mt-6"><button id="skip-btn" class="btn-game btn-info px-8 py-2 text-lg">Skip</button></div>`;
        getEl('speaker-btn').onclick = () => speak(correctAnswer);
        getEl('skip-btn').onclick = () => { playSound('A3', '0.1'); nextQuestion(); };
        document.querySelectorAll('.option-btn').forEach(btn => btn.onclick = () => handleAnswer(btn, correctAnswer));
        speak(correctAnswer);
    };
    const handleAnswer = (btn, correctAnswer) => {
        document.querySelectorAll('.option-btn').forEach(b => b.disabled = true);
        if (btn.dataset.letter === correctAnswer) { playSound('G4', '0.1'); correctAnswers++; updateScore(10); btn.classList.replace('btn-secondary', 'btn-accent'); setTimeout(nextQuestion, 800); } 
        else { playSound('C3', '0.1'); btn.classList.replace('btn-secondary', 'btn-danger'); setTimeout(() => { document.querySelectorAll('.option-btn').forEach(b => { b.disabled = false; b.classList.replace('btn-danger', 'btn-secondary'); }); }, 800); }
    };
    nextQuestion();
}

// --- STAGE 2: Letter Tracing ---
function loadStage2(levelData) {
    let letterIndex = 0; let tracedCount = 0;
    const nextLetter = () => {
        if (tracedCount >= levelData.target) { levelWon(); return; }
        const letterToTrace = levelData.letters[letterIndex];
        const detail = letterDetails[letterToTrace];
        const paths = letterTracePaths[letterToTrace];
        getEl('game-area').innerHTML = `<div class="flex flex-col md:flex-row items-center justify-center gap-4 md:gap-8 w-full h-full"><div id="trace-canvas-container" class="bg-white rounded-2xl shadow-inner flex-shrink-0"><canvas id="guide-canvas"></canvas><canvas id="trace-canvas"></canvas></div><div class="flex flex-col items-center gap-4"><img id="object-image" src="${detail.image}" class="w-32 h-32 md:w-48 md:h-48 object-contain rounded-2xl bg-white shadow-lg cursor-pointer" onerror="this.src='https://placehold.co/200x200/cccccc/FFFFFF?text=Image'"><div class="font-header text-5xl text-slate-600">${detail.word}</div><div class="flex gap-4"><button id="show-example-btn" class="btn-game btn-info px-6 py-2">Show Example</button><button id="clear-canvas-btn" class="btn-game btn-danger px-6 py-2">Clear</button></div></div>`;
        
        const canvases = { guide: getEl('guide-canvas'), trace: getEl('trace-canvas') };
        const ctxs = { guide: canvases.guide.getContext('2d'), trace: canvases.trace.getContext('2d') };
        const container = getEl('trace-canvas-container');
        const dpr = window.devicePixelRatio || 1; const rect = container.getBoundingClientRect();
        Object.values(canvases).forEach(c => { c.width = rect.width * dpr; c.height = rect.height * dpr; ctxs[c.id.split('-')[0]].scale(dpr, dpr); });
        
        let currentStrokeIndex = 0; let isDrawing = false;
        
        const drawGuide = () => {
            ctxs.guide.clearRect(0, 0, rect.width, rect.height);
            ctxs.guide.globalAlpha = 0.2;
            ctxs.guide.lineWidth = 20; ctxs.guide.lineCap = 'round';
            paths.forEach(stroke => {
                ctxs.guide.beginPath();
                ctxs.guide.moveTo(stroke[0].x, stroke[0].y);
                for(let i = 1; i < stroke.length; i++) { ctxs.guide.lineTo(stroke[i].x, stroke[i].y); }
                ctxs.guide.strokeStyle = '#334155';
                ctxs.guide.stroke();
            });
            ctxs.guide.globalAlpha = 1.0;
            
            paths.forEach((stroke, strokeIdx) => {
                if (strokeIdx < currentStrokeIndex) {
                    ctxs.guide.beginPath();
                    ctxs.guide.moveTo(stroke[0].x, stroke[0].y);
                    for(let i = 1; i < stroke.length; i++) { ctxs.guide.lineTo(stroke[i].x, stroke[i].y); }
                    ctxs.guide.strokeStyle = 'var(--c-primary-dark)'; ctxs.guide.stroke();
                }
            });

            const currentStartPoint = paths[currentStrokeIndex]?.[0];
            if(currentStartPoint) {
                ctxs.guide.beginPath();
                ctxs.guide.arc(currentStartPoint.x, currentStartPoint.y, 12, 0, 2 * Math.PI);
                ctxs.guide.fillStyle = 'var(--c-info)';
                ctxs.guide.shadowColor = 'rgba(96, 165, 250, 0.8)';
                ctxs.guide.shadowBlur = 15;
                ctxs.guide.fill();
                ctxs.guide.shadowColor = 'transparent'; ctxs.guide.shadowBlur = 0;

                ctxs.guide.font = '14px Fredoka One'; ctxs.guide.fillStyle = 'white'; ctxs.guide.textAlign = 'center'; ctxs.guide.textBaseline = 'middle';
                ctxs.guide.fillText(currentStrokeIndex + 1, currentStartPoint.x, currentStartPoint.y);
            }
        };
        drawGuide();
        
        getEl('object-image').onclick = () => speak(detail.word);
        getEl('clear-canvas-btn').onclick = () => { ctxs.trace.clearRect(0, 0, rect.width, rect.height); };
        getEl('show-example-btn').onclick = () => animateGuide();
        speak(`${letterToTrace} is for ${detail.word}`);

        let lastX = 0, lastY = 0;
        const getCoords = (e) => { const r = canvases.trace.getBoundingClientRect(); const evt = e.touches ? e.touches[0] : e; return [evt.clientX - r.left, evt.clientY - r.top]; };
        
        const startDrawing = (e) => {
            const startPoint = paths[currentStrokeIndex]?.[0];
            if (!startPoint) return;
            const [x,y] = getCoords(e);
            if(Math.hypot(x - startPoint.x, y - startPoint.y) < 25) {
                isDrawing = true; [lastX, lastY] = [x, y];
                ctxs.trace.beginPath(); ctxs.trace.moveTo(lastX, lastY);
            }
        };
        const draw = (e) => {
            if(!isDrawing) return; e.preventDefault();
            const [x, y] = getCoords(e);
            ctxs.trace.lineTo(x, y);
            ctxs.trace.strokeStyle = `var(--c-primary)`;
            ctxs.trace.lineWidth = 14; ctxs.trace.lineCap = 'round'; ctxs.trace.lineJoin = 'round';
            ctxs.trace.stroke();
            lastX = x; lastY = y;
        };
        const stopDrawing = () => {
            if(!isDrawing) return; isDrawing = false;
            const endPoint = paths[currentStrokeIndex]?.[paths[currentStrokeIndex].length - 1];
            if(endPoint && Math.hypot(lastX - endPoint.x, lastY - endPoint.y) < 25) {
                playSound('E5', '0.05');
                ctxs.trace.clearRect(0,0,rect.width, rect.height);
                currentStrokeIndex++;
                drawGuide(); // Update guide for next stroke
                if (currentStrokeIndex >= paths.length) {
                    playSound('C5', '0.2'); tracedCount++; letterIndex++; updateScore(25); setTimeout(nextLetter, 800);
                }
            } else { playSound('C3', '0.1'); setTimeout(()=> ctxs.trace.clearRect(0, 0, rect.width, rect.height), 500); }
        };
        const animateGuide = () => {
            let strokeIdx = 0, pointIdx = 0, progress = 0, animationFrameId;
            ctxs.trace.clearRect(0,0,rect.width, rect.height);
            ctxs.trace.lineWidth = 14; ctxs.trace.lineCap = 'round'; ctxs.trace.strokeStyle = `var(--c-accent)`;
            function animate() {
                if(strokeIdx >= paths.length) { setTimeout(() => ctxs.trace.clearRect(0,0,rect.width, rect.height), 500); return; }
                progress += 0.05;
                const p1 = paths[strokeIdx][pointIdx];
                const p2 = paths[strokeIdx][pointIdx+1];
                const x = p1.x + (p2.x - p1.x) * progress;
                const y = p1.y + (p2.y - p1.y) * progress;
                ctxs.trace.lineTo(x,y); ctxs.trace.stroke();
                if(progress >= 1) {
                    progress = 0; pointIdx++;
                    if(pointIdx >= paths[strokeIdx].length -1) {
                        strokeIdx++; pointIdx = 0;
                        if(strokeIdx < paths.length) { ctxs.trace.beginPath(); ctxs.trace.moveTo(paths[strokeIdx][0].x, paths[strokeIdx][0].y); }
                    } else {
                        ctxs.trace.beginPath(); ctxs.trace.moveTo(paths[strokeIdx][pointIdx].x, paths[strokeIdx][pointIdx].y);
                    }
                }
                animationFrameId = requestAnimationFrame(animate);
            }
            ctxs.trace.beginPath(); ctxs.trace.moveTo(paths[0][0].x, paths[0][0].y);
            animate();
        };
        
        canvases.trace.addEventListener('pointerdown', startDrawing);
        canvases.trace.addEventListener('pointermove', draw);
        canvases.trace.addEventListener('pointerup', stopDrawing);
        canvases.trace.addEventListener('pointerleave', stopDrawing);
    };
    nextLetter();
}


function loadStage3(levelData) {
    let correctAnswers = 0;
    const nextQuestion = () => {
        if (correctAnswers >= levelData.target) { levelWon(); return; }
        const availableLetters = Object.keys(levelData.words);
        const correctLetter = availableLetters[Math.floor(Math.random() * availableLetters.length)];
        const correctWord = levelData.words[correctLetter];
        const options = new Set([correctWord]);
        while(options.size < 3) { options.add(levelData.words[availableLetters[Math.floor(Math.random() * availableLetters.length)]]) }
        const shuffledOptions = Array.from(options).sort(() => Math.random() - 0.5);
        getEl('game-area').innerHTML = `<div class="text-center"><p class="text-2xl sm:text-3xl text-slate-700">Which word starts with:</p><div class="flex items-center justify-center gap-4 my-2 sm:my-4"><h2 class="font-header text-8xl sm:text-9xl text-rose-500">${correctLetter}</h2><button id="speaker-btn" class="btn-icon text-5xl">🔊</button></div></div><div class="flex flex-col sm:flex-row gap-2 sm:gap-4 mt-4 flex-wrap justify-center">${shuffledOptions.map(word => `<button class="word-option-btn btn-game btn-primary text-2xl sm:text-3xl p-4 w-64 h-20 sm:h-24 flex items-center justify-center rounded-3xl" data-word="${word}">${word}</button>`).join('')}</div><div class="mt-6"><button id="skip-btn" class="btn-game btn-info px-8 py-2 text-lg">Skip</button></div>`;
        getEl('speaker-btn').onclick = () => speak(correctLetter);
        getEl('skip-btn').onclick = () => { playSound('A3', '0.1'); nextQuestion(); };
        document.querySelectorAll('.word-option-btn').forEach(btn => btn.onclick = () => handleAnswer(btn, correctLetter));
        speak(correctLetter);
    };
    const handleAnswer = (btn, correctLetter) => {
        document.querySelectorAll('.word-option-btn').forEach(b => b.disabled = true);
        if (btn.dataset.word.startsWith(correctLetter)) { playSound('A4', '0.1'); correctAnswers++; updateScore(10); btn.classList.replace('btn-primary', 'btn-accent'); setTimeout(nextQuestion, 800); } 
        else { playSound('D3', '0.1'); btn.classList.replace('btn-primary', 'btn-danger'); setTimeout(() => { document.querySelectorAll('.word-option-btn').forEach(b => { b.disabled = false; b.classList.replace('btn-danger', 'btn-primary'); }); }, 800); }
    };
    nextQuestion();
}

function loadStage4(levelData) {
    const { pairs } = levelData; const lettersForGame = alphabet.slice().sort(() => 0.5 - Math.random()).slice(0, pairs);
    const cards = [...lettersForGame, ...lettersForGame.map(l => l.toLowerCase())].sort(() => 0.5 - Math.random());
    getEl('game-area').innerHTML = `<div class="text-center mb-4"><p class="text-2xl sm:text-3xl text-slate-700">Match the capital to its small letter!</p></div><div class="grid gap-2 sm:gap-4 w-full max-w-2xl" style="grid-template-columns: repeat(auto-fit, minmax(80px, 1fr))">${cards.map(card => `<div class="card-container h-24 sm:h-32"><div class="card" data-letter="${card.toUpperCase()}"><div class="card-face card-front text-4xl font-header">?</div><div class="card-face card-back text-4xl sm:text-5xl font-bold">${card}</div></div></div>`).join('')}</div>`;
    let flippedCards = []; let matchedPairs = 0;
    document.querySelectorAll('.card').forEach(card => {
        card.onclick = () => {
            if (flippedCards.length < 2 && !card.classList.contains('flipped') && !card.classList.contains('matched')) {
                playSound('E4', '0.05'); card.classList.add('flipped'); flippedCards.push(card);
                if (flippedCards.length === 2) { setTimeout(checkMatch, 800); }
            }
        };
    });
    function checkMatch() {
        const [card1, card2] = flippedCards;
        if (card1.dataset.letter === card2.dataset.letter) { playSound('G5', '0.1'); matchedPairs++; updateScore(15); card1.classList.add('matched'); card2.classList.add('matched'); if (matchedPairs === pairs) { setTimeout(levelWon, 500); } } 
        else { playSound('C3', '0.1'); card1.classList.remove('flipped'); card2.classList.remove('flipped'); }
        flippedCards = [];
    }
}

function loadStage5(levelData) {
    let correctAnswers = 0; let currentTargetLetter = '';
    getEl('game-area').innerHTML = `<div id="flying-area" class="w-full h-full relative overflow-hidden rounded-2xl"><div id="flying-instruction" class="absolute top-4 left-1/2 -translate-x-1/2 bg-black/60 p-4 rounded-full text-white text-xl sm:text-3xl z-10 font-bold"></div></div>`;
    let letters = [];
    const flyingArea = getEl('flying-area');

    const nextTarget = () => {
        const remaining = letters.filter(l => !l.clicked);
        if (remaining.length === 0 || correctAnswers >= levelData.target) {
            if (correctAnswers >= levelData.target) levelWon(); else levelLost();
            if (animationFrameId) cancelAnimationFrame(animationFrameId);
            return;
        }
        currentTargetLetter = remaining[Math.floor(Math.random() * remaining.length)].letter;
        getEl('flying-instruction').innerHTML = `Click on the letter <span class="text-yellow-300">${currentTargetLetter}</span>! <button id="speaker-btn" class="btn-icon text-3xl align-middle">🔊</button>`;
        getEl('speaker-btn').onclick = () => speak(currentTargetLetter);
        speak(`Click on the letter ${currentTargetLetter}`);
    };
    
    for (let i = 0; i < 25; i++) {
        const letterChar = alphabet[Math.floor(Math.random() * alphabet.length)];
        const el = document.createElement('div'); el.className = 'flying-letter absolute text-6xl cursor-pointer';
        el.textContent = Math.random() > 0.5 ? letterChar : letterChar.toLowerCase();
        flyingArea.appendChild(el);
        
        letters.push({
            el: el,
            letter: letterChar,
            x: Math.random() * flyingArea.offsetWidth,
            y: Math.random() * flyingArea.offsetHeight + flyingArea.offsetHeight,
            vx: (Math.random() - 0.5) * 2,
            vy: - (Math.random() * 1 + 1),
            clicked: false,
        });
        
        el.onclick = (e) => {
            const letterObj = letters.find(l => l.el === e.target);
            if(letterObj && letterObj.letter === currentTargetLetter) {
                playSound('B4', '0.1'); correctAnswers++; updateScore(20);
                letterObj.clicked = true;
                letterObj.el.style.transition = 'transform 0.2s ease, opacity 0.2s ease';
                letterObj.el.style.transform = 'scale(1.5)'; letterObj.el.style.opacity = '0';
                setTimeout(() => letterObj.el.remove(), 200);
                nextTarget();
            } else { playSound('D3', '0.1'); }
        };
    }
    
    let animationFrameId;
    function gameLoop() {
        letters.forEach(l => {
            if (!l.clicked) {
                l.x += l.vx;
                l.y += l.vy;
                if(l.y < -60) { l.y = flyingArea.offsetHeight + 60; l.x = Math.random() * flyingArea.offsetWidth; }
                if(l.x < -60 || l.x > flyingArea.offsetWidth + 60) { l.vx *= -1; }
                l.el.style.transform = `translate(${l.x}px, ${l.y}px)`;
            }
        });
        animationFrameId = requestAnimationFrame(gameLoop);
    }

    nextTarget();
    gameLoop();
}

// --- WIN SCREEN & CONFETTI ---
function showWinScreen() { clearInterval(game.timerInterval); showScreen('win'); getEl('win-cert-name').textContent = game.playerName; playWinMusic(); launchConfetti(); }
function launchConfetti() { const canvas = getEl('confetti-canvas'); if (!canvas) return; const ctx = canvas.getContext('2d'); canvas.width = window.innerWidth; canvas.height = window.innerHeight; let confetti = []; const confettiCount = 200; const colors = ['#f43f5e', '#ec4899', '#d946ef', '#a855f7', '#8b5cf6', '#6366f1', '#3b82f6', '#0ea5e9', '#06b6d4', '#14b8a6', '#22c55e', '#84cc16', '#eab308', '#f97316', '#ef4444']; for (let i = 0; i < confettiCount; i++) { confetti.push({ x: Math.random() * canvas.width, y: Math.random() * canvas.height - canvas.height, size: Math.random() * 6 + 3, speed: Math.random() * 5 + 2, color: colors[Math.floor(Math.random() * colors.length)], angle: Math.random() * Math.PI * 2, spin: Math.random() * 0.2 - 0.1 }); } let animationFrameId; function animateConfetti() { ctx.clearRect(0, 0, canvas.width, canvas.height); confetti.forEach((c, index) => { c.y += c.speed; c.x += Math.sin(c.angle); c.angle += c.spin; ctx.fillStyle = c.color; ctx.beginPath(); ctx.roundRect(c.x, c.y, c.size, c.size, [c.size / 2]); ctx.fill(); if (c.y > canvas.height) { confetti.splice(index, 1); } }); if (confetti.length > 0) { animationFrameId = requestAnimationFrame(animateConfetti); } else { ctx.clearRect(0, 0, canvas.width, canvas.height); cancelAnimationFrame(animationFrameId); } } animateConfetti(); }
if (!CanvasRenderingContext2D.prototype.roundRect) { CanvasRenderingContext2D.prototype.roundRect = function(x, y, w, h, r) { r=r[0];this.beginPath();this.moveTo(x+r,y);this.arcTo(x+w,y,x+w,y+h,r);this.arcTo(x+w,y+h,x,y+h,r);this.arcTo(x,y+h,x,y,r);this.arcTo(x,y,x+w,y,r);this.closePath();}; }

// --- INITIAL SETUP ---
document.addEventListener('DOMContentLoaded', () => {
    const mapContainer = getEl('map-container');
    mapContainer.innerHTML = '';
    const stageColors = ['#60a5fa', '#4ade80', '#f87171', '#facc15', '#c084fc'];
    stages.forEach((stage, i) => {
        const node = document.createElement('div');
        node.className = 'stage-node relative z-10 w-28 h-28 md:w-32 md:h-32 flex flex-col items-center justify-center rounded-full';
        node.style.backgroundColor = stageColors[i]; node.dataset.stage = i;
        const textColor = i === 3 ? 'text-gray-800' : 'text-white';
        node.innerHTML = `<div class="${textColor} text-3xl font-header">${i+1}</div><div class="${textColor} text-md font-bold text-center px-1">${stage.name}</div>`;
        mapContainer.appendChild(node);
    });
    
    getEl('start-game-btn').onclick = () => {
        const name = getEl('player-name-input').value.trim();
        if (name) {
            game.playerName = (name.toUpperCase() === 'DEVMODE') ? 'Developer' : name;
            game.devMode = (name.toUpperCase() === 'DEVMODE');
            game.unlockedStages = game.devMode ? stages.length : 1;
            showScreen('map');
            updateMap(true);
        }
    };
    
    getEl('play-again-btn').onclick = () => location.reload();
    getEl('back-to-map-btn').onclick = () => { clearInterval(game.timerInterval); showScreen('map'); updateMap(); };
    getEl('retry-level-btn').onclick = () => { playSound('E4', '0.1'); loadLevel(); };
    showScreen('name');
});
